package com.proxy.connection;

public class RealInternet implements Internet {

	@Override
	public void ConnectTo(String serverhost) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Connecting to... " +serverhost);
	}
	
	

}
