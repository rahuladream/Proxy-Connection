package com.proxy.connection;

import java.util.ArrayList;
import java.util.List;

public class ProxyInternet implements Internet {
  
	private Internet internet = new RealInternet();
	private static List<String> bannedSites;
	
	static 
	{
		bannedSites = new ArrayList<String>();
		bannedSites.add("abc.com");
		bannedSites.add("google.com");
		bannedSites.add("nastyweb.com");
	}
	
	@Override
	public void ConnectTo(String serverhost) throws Exception {
		// TODO Auto-generated method stub
		
		if(bannedSites.contains(serverhost.toLowerCase()))
		
		{
			throw new Exception("! >> Access Denied << ! ");
		}
		internet.ConnectTo(serverhost);
	}
	

}
