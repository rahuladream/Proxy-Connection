package com.proxy.connection;

public interface Internet {
	
	public void ConnectTo(String serverhost) throws Exception;

}
