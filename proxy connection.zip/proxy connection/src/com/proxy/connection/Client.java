package com.proxy.connection;

import java.util.Scanner;

public class Client {
   static Scanner read = new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Internet internet = new ProxyInternet();
		try
		{   
			System.out.println("enter site to check connection : ");
		    String site = read.nextLine();
			internet.ConnectTo(site);
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage());
		}

	}

}
